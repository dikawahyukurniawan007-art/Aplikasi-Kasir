import 'package:flutter/material.dart';
import '../models/product.dart';

final List<Product> dummyProducts = [
  Product(
    id: 'p1',
    name: 'Ayam Tanpa Nasi',
    price: 14000,
    color: Colors.orange.shade400,
    imageUrl: 'https://picsum.photos/seed/bakpau-ayam/400/400',
    stock: 20,
  ),
  Product(
    id: 'p2',
    name: 'Kacang Hijau',
    price: 5000,
    color: Colors.green.shade400,
    imageUrl: 'https://picsum.photos/seed/bakpau-kacang-hijau/400/400',
    stock: 20,
  ),
  Product(
    id: 'p3',
    name: 'Coklat',
    price: 5000,
    color: Colors.brown.shade400,
    imageUrl: 'https://picsum.photos/seed/bakpau-coklat/400/400',
    stock: 20,
  ),
  Product(
    id: 'p4',
    name: 'Keju',
    price: 6000,
    color: Colors.amber.shade600,
    imageUrl: 'https://picsum.photos/seed/bakpau-keju/400/400',
    stock: 20,
  ),
  Product(
    id: 'p5',
    name: 'Daging Sapi',
    price: 8000,
    color: Colors.red.shade400,
    imageUrl: 'https://picsum.photos/seed/bakpau-daging-sapi/400/400',
    stock: 20,
  ),
  Product(
    id: 'p6',
    name: 'Kacang Merah',
    price: 5000,
    color: Colors.red.shade200,
    imageUrl: 'https://picsum.photos/seed/bakpau-kacang-merah/400/400',
    stock: 20,
  ),
  Product(
    id: 'p7',
    name: 'Ubi Ungu',
    price: 6000,
    color: Colors.purple.shade300,
    imageUrl: 'https://picsum.photos/seed/bakpau-ubi-ungu/400/400',
    stock: 20,
  ),
  Product(
    id: 'p8',
    name: 'Strawberry',
    price: 5500,
    color: Colors.pink.shade300,
    imageUrl: 'https://picsum.photos/seed/bakpau-strawberry/400/400',
    stock: 20,
  ),
];