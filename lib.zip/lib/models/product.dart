import 'package:flutter/material.dart';

class Product {
  final String id;
  final String name;
  final int price;
  final Color color;
  final String imageUrl;
  int stock;

  Product({
    required this.id,
    required this.name,
    required this.price,
    required this.color,
    required this.imageUrl,
    required this.stock,
  });
}