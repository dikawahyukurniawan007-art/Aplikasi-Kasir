import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/cart_provider.dart';
import '../widgets/product_card.dart';
import '../widgets/cart_panel.dart';
import '../models/product.dart';
import 'history_screen.dart';

class PosScreen extends StatelessWidget {
  const PosScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        foregroundColor: Colors.white,
        flexibleSpace: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Theme.of(context).colorScheme.primary,
                Theme.of(context).colorScheme.primary.withOpacity(0.75),
              ],
            ),
          ),
        ),
        title: const Text('Kasir Bakpau', style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            icon: const Icon(Icons.receipt_long),
            tooltip: 'Riwayat & Excel',
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const HistoryScreen()),
            ),
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 700;
          
          // Menggunakan ListView untuk tampilan seperti gambar
          final productList = _ProductList();

          if (isWide) {
            return Row(
              children: [
                Expanded(flex: 3, child: productList),
                const VerticalDivider(width: 1),
                const SizedBox(width: 320, child: CartPanel()),
              ],
            );
          }

          return Stack(
            children: [
              Padding(padding: const EdgeInsets.only(bottom: 72), child: productList),
              if (cart.cartItems.isNotEmpty)
                const Align(alignment: Alignment.bottomCenter, child: _MiniCartBar()),
            ],
          );
        },
      ),
    );
  }
}

class _ProductList extends StatelessWidget {
  // Dialog untuk mengedit stok
  void _showEditStockDialog(BuildContext context, Product product) {
    final TextEditingController controller = TextEditingController(text: product.stock.toString());
    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: Text('Edit Stok: ${product.name}'),
          content: TextField(
            controller: controller,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Jumlah Stok',
              border: OutlineInputBorder(),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('Batal'),
            ),
            FilledButton(
              onPressed: () {
                final newStock = int.tryParse(controller.text) ?? product.stock;
                context.read<CartProvider>().updateProductStock(product.id, newStock);
                Navigator.pop(ctx);
              },
              child: const Text('Simpan'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return ListView.builder(
      padding: const EdgeInsets.all(12),
      itemCount: cart.products.length,
      itemBuilder: (context, index) {
        final product = cart.products[index];
        final quantity = cart.getQuantity(product.id);
        
        return ProductCard(
          product: product,
          quantity: quantity,
          onAdd: () {
            final success = cart.addToCart(product);
            if (!success) {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Stok ${product.name} tidak mencukupi!'),
                  duration: const Duration(seconds: 1),
                ),
              );
            }
          },
          onRemove: () => cart.decrement(product.id),
          onEditStock: () => _showEditStockDialog(context, product),
        );
      },
    );
  }
}

class _MiniCartBar extends StatelessWidget {
  const _MiniCartBar();

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    return SafeArea(
      child: Container(
        margin: const EdgeInsets.all(12),
        child: Material(
          elevation: 4,
          borderRadius: BorderRadius.circular(16),
          color: Theme.of(context).colorScheme.primary,
          child: InkWell(
            borderRadius: BorderRadius.circular(16),
            onTap: () => showModalBottomSheet(
              context: context,
              isScrollControlled: true,
              shape: const RoundedRectangleBorder(
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              builder: (_) => const SizedBox(height: 500, child: CartPanel()),
            ),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Icon(Icons.shopping_cart, color: Theme.of(context).colorScheme.onPrimary),
                  const SizedBox(width: 8),
                  Text(
                    '${cart.totalItemCount} item',
                    style: TextStyle(color: Theme.of(context).colorScheme.onPrimary, fontWeight: FontWeight.bold),
                  ),
                  const Spacer(),
                  Text('Lihat Keranjang', style: TextStyle(color: Theme.of(context).colorScheme.onPrimary)),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}