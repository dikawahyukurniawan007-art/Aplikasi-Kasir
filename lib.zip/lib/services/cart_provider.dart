import 'package:flutter/material.dart';
import '../models/product.dart';
import '../models/cart_item.dart';
import '../models/transaction.dart';
import '../data/dummy_products.dart';
import 'excel_service.dart';

class CartProvider extends ChangeNotifier {
  final List<Product> products = dummyProducts;
  final Map<String, CartItem> _cart = {};
  final List<TransactionData> _history = [];
  final ExcelService _excelService = ExcelService();

  List<CartItem> get cartItems => _cart.values.toList();
  List<TransactionData> get history => List.unmodifiable(_history.reversed);
  int get totalItemCount => _cart.values.fold(0, (sum, item) => sum + item.quantity);
  int get totalPrice => _cart.values.fold(0, (sum, item) => sum + item.subtotal);

  // Mendapatkan jumlah kuantitas produk tertentu di keranjang
  int getQuantity(String productId) {
    return _cart[productId]?.quantity ?? 0;
  }

  bool _isToday(DateTime date) {
    final now = DateTime.now();
    return date.year == now.year && date.month == now.month && date.day == now.day;
  }

  int get todayTransactionCount => _history.where((t) => _isToday(t.date)).length;
  int get todayRevenue =>
      _history.where((t) => _isToday(t.date)).fold(0, (sum, t) => sum + t.total);

  void updateProductStock(String productId, int newStock) {
    final productIndex = products.indexWhere((p) => p.id == productId);
    if (productIndex != -1) {
      products[productIndex].stock = newStock;
      notifyListeners();
    }
  }

  bool addToCart(Product product) {
    final currentQty = _cart[product.id]?.quantity ?? 0;
    if (currentQty >= product.stock) {
      return false; // Stok tidak cukup
    }

    if (_cart.containsKey(product.id)) {
      _cart[product.id]!.quantity++;
    } else {
      _cart[product.id] = CartItem(product: product);
    }
    notifyListeners();
    return true;
  }

  void increment(String productId) {
    final item = _cart[productId];
    if (item == null) return;
    
    if (item.quantity < item.product.stock) {
      item.quantity++;
      notifyListeners();
    }
  }

  void decrement(String productId) {
    final item = _cart[productId];
    if (item == null) return;
    if (item.quantity <= 1) {
      _cart.remove(productId);
    } else {
      item.quantity--;
    }
    notifyListeners();
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  Future<TransactionData> checkout(int paid) async {
    final trx = TransactionData.fromCart(cartItems: cartItems, paid: paid);
    
    // Kurangi stok
    for (var item in cartItems) {
      final productIndex = products.indexWhere((p) => p.id == item.product.id);
      if (productIndex != -1) {
        products[productIndex].stock -= item.quantity;
      }
    }

    _history.add(trx);
    clearCart();
    notifyListeners();
    await _excelService.appendTransaction(trx);
    return trx;
  }

  Future<String> exportExcelPath() => _excelService.getFilePath();
  Future<void> shareExcel() => _excelService.shareFile();
}